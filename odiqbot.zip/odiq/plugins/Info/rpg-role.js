// Klo mau pake, pake aja ini bkn enc cma terser aja

// Klo mau pake, pake aja ini bkn enc cma terser aja

let handler = async (m, { mufar }) => {
  let user = global.db.data.users[m.sender]
        let role = (user.level <= 2) ? 'Warior'
          : ((user.level >= 2) && (user.level <= 4)) ? 'Warior 1 ⚊¹'
          : ((user.level >= 4) && (user.level <= 6)) ? 'Warior 2 ⚊²'
          : ((user.level >= 6) && (user.level <= 8)) ? 'Warior 3 ⚊³'
          : ((user.level >= 8) && (user.level <= 10)) ? 'Warior 4 ⚊⁴'
          : ((user.level >= 10) && (user.level <= 20)) ? 'Elite 1 ⚌¹'
          : ((user.level >= 20) && (user.level <= 30)) ? 'Elite 2 ⚌²'
          : ((user.level >= 30) && (user.level <= 40)) ? 'Elite 3 ⚌³'
          : ((user.level >= 40) && (user.level <= 50)) ? 'Elite 4 ⚌⁴'
          : ((user.level >= 50) && (user.level <= 60)) ? 'Elite 5 ⚌⁵'
          : ((user.level >= 60) && (user.level <= 70)) ? 'Master 1 ☰¹' 
          : ((user.level >= 70) && (user.level <= 80)) ? 'Master 2 ☰²' 
          : ((user.level >= 80) && (user.level <= 90)) ? 'Master 3 ☰³' 
          : ((user.level >= 90) && (user.level <= 100)) ? 'Master 4 ☰⁴' 
          : ((user.level >= 100) && (user.level <= 110)) ? 'Master 5 ☰⁵'
          : ((user.level >= 110) && (user.level <= 120)) ? 'Grand Master 1 ≣¹'
          : ((user.level >= 120) && (user.level <= 130)) ? 'Grand Master 2 ≣²'
          : ((user.level >= 130) && (user.level <= 140)) ? 'Grand Master 3 ≣³'
          : ((user.level >= 140) && (user.level <= 150)) ? 'Grand Master 4 ≣⁴'
          : ((user.level >= 150) && (user.level <= 160)) ? 'Grand Master 5 ≣⁵' 
          : ((user.level >= 160) && (user.level <= 170)) ? 'Epic 1 ﹀¹' 
          : ((user.level >= 170) && (user.level <= 180)) ? 'Epic 2 ﹀²' 
          : ((user.level >= 180) && (user.level <= 190)) ? 'Epic 3 ﹀³' 
          : ((user.level >= 190) && (user.level <= 200)) ? 'Epic 4 ﹀⁴' 
          : ((user.level >= 200) && (user.level <= 210)) ? 'Epic 5 ﹀⁵' 
          : ((user.level >= 210) && (user.level <= 220)) ? 'Legend 1 ︾¹'
          : ((user.level >= 220) && (user.level <= 230)) ? 'Legend 2 ︾²'
          : ((user.level >= 230) && (user.level <= 240)) ? 'Legend 3 ︾³'
          : ((user.level >= 240) && (user.level <= 250)) ? 'Legend 4 ︾⁴'
          : ((user.level >= 250) && (user.level <= 260)) ? 'Legend 5 ︾⁵'
          : ((user.level >= 260) && (user.level <= 270)) ? 'Mythic 1 ♢¹'
          : ((user.level >= 270) && (user.level <= 280)) ? 'Mythic 2 ♢²'  
          : ((user.level >= 280) && (user.level <= 290)) ? 'Mythic 3 ♢³' 
          : ((user.level >= 290) && (user.level <= 300)) ? 'Mythic 4 ♢⁴' 
          : ((user.level >= 300) && (user.level <= 310)) ? 'Mythic 5 ♢⁵'
          : ((user.level >= 310) && (user.level <= 320)) ? 'Mythical Honor 1 ♢♢¹'
          : ((user.level >= 320) && (user.level <= 330)) ? 'Mythical Honor 2 ♢♢²'
          : ((user.level >= 330) && (user.level <= 340)) ? 'Mythical Honor 3 ♢♢³'
          : ((user.level >= 340) && (user.level <= 350)) ? 'Mythical Honor 4 ♢♢⁴'
          : ((user.level >= 350) && (user.level <= 360)) ? 'Mythical Honor 5 ♢♢⁵'
          : ((user.level >= 360) && (user.level <= 370)) ? 'Mythical Glory 1 ✷¹'
          : ((user.level >= 370) && (user.level <= 380)) ? 'Mythical Glory 2 ✷²'
          : ((user.level >= 380) && (user.level <= 390)) ? 'Mythical Glory 3 ✷³'
          : ((user.level >= 390) && (user.level <= 400)) ? 'Mythical Glory 4 ✷⁴'
          : ((user.level >= 400) && (user.level <= 410)) ? 'Mythical Glory 5 ✷⁵'
          : ((user.level >= 410) && (user.level <= 420)) ? 'Mythical Immortal 1 ✷✷¹'
          : ((user.level >= 420) && (user.level <= 430)) ? 'Mythical Immortal 2 ✷✷²'
          : ((user.level >= 430) && (user.level <= 440)) ? 'Mythical Immortal 3 ✷✷³'
          : ((user.level >= 440) && (user.level <= 450)) ? 'Mythical Immortal 4 ✷✷⁴'
          : ((user.level >= 450) && (user.level <= 460)) ? 'Mythical Immortal 5 ✷✷⁵'
          : ((user.level >= 460) && (user.level <= 470)) ? 'Moyang ✰'
          : ((user.level >= 470) && (user.level <= 480)) ? 'Moyang ✩'
          : ((user.level >= 480) && (user.level <= 490)) ? 'Moyang ✯' 
          : ((user.level >= 490) && (user.level <= 500)) ? 'Moyang ✬'
          : ((user.level >= 500) && (user.level <= 600)) ? 'Moyang ✪'
          : ((user.level >= 600) && (user.level <= 700)) ? 'Sepug 忍'
          : ((user.level >= 700) && (user.level <= 800)) ? 'Sepuh 忍忍'
          : ((user.level >= 800) && (user.level <= 900)) ? 'Sepuh 忍忍忍'
          : ((user.level >= 900) && (user.level <= 1000)) ? 'Sepuh忍忍忍忍'
          : 'Sepuhnya Para Sepuh 숒'
  user.role = role
  await mufar.reply(m.chat, "*Kamu adalah:* " + user.role, m)
}
handler.help = ['role']
handler.tags = ['info']
handler.command = /^(role|levelrole)$/i
handler.register = true
export default handler