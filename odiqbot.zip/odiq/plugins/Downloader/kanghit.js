// Klo mau pake, pake aja ini bkn enc cma terser aja

// Klo mau pake, pake aja ini bkn enc cma terser aja

import axios from 'axios'

async function apivisit() {
axios.get(`https://status.pnggilajacn.my.id`);
axios.get(`https://status.pnggilajacn.my.id`);
}
	// By Chandra XD
	// Follow bang
	// TikTok : @pnggilajacn
	// Github : https://github.com/Chandra-XD
export { 
    apivisit 
}
