// Klo mau pake, pake aja ini bkn enc cma terser aja

// Klo mau pake, pake aja ini bkn enc cma terser aja

import jimp from 'jimp'

let handler = async (m, { mufar, text }) => {
	let img = await jimp.read('https://i.imgur.com/nav6WWX.png'),
		who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender,
		avatar = await jimp.read(await mufar.profilePictureUrl(who, 'image')),
		bonk = await img.composite(avatar.resize(128, 128), 120, 90, {
			mode: 'dstOver',
			opacitySource: 1,
			opacityDest: 1
		}).getBufferAsync('image/png')
	mufar.sendMessage(m.chat, { image: bonk }, { quoted: m })
}
handler.help = handler.command = ['bonk']
handler.tags = ['maker']
export default handler
