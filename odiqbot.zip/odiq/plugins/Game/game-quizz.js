// Klo mau pake, pake aja ini bkn enc cma terser aja

// Klo mau pake, pake aja ini bkn enc cma terser aja

import fetch from 'node-fetch'
let timeout = 120000
let poin = 4999
let handler = async (m, { mufar, text, command, usedPrefix }) => {
let imgr = flaaa.getRandom()

    mufar.quizz = mufar.quizz ? mufar.quizz : {}
    let id = m.chat
    if (!text)
      return m.reply(
        `Please use this command like this: ${usedPrefix}quizz easy/medium/hard`
      );
    if (id in mufar.quizz) {
        mufar.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', mufar.quizz[id][0])
        throw false
    }
    
  let json = await quizApi(text)
  let caption = `            *『  quizz Answers  』*\n\n📒  *quizz:* ${json[0].soal}
  
Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}quizzh untuk bantuan
Bonus: ${poin} XP
    `.trim()
    mufar.quizz[id] = [
        await mufar.sendFile(m.chat, imgr + command, '', caption, m),
        json, poin,
        setTimeout(() => {
            if (mufar.quizz[id]) mufar.reply(m.chat, `Waktu habis!\\n\n🎋  *Answer:* ${json[0].jawaban}\n
`, mufar.quizz[id][0])
            delete mufar.quizz[id]
        }, timeout)
    ]
}
handler.help = ['quizz']
handler.tags = ['game']
handler.command = /^quizz/i

export default handler

const buttons = [
    ['Hint', '/quizzh'],
    ['Nyerah', 'menyerah']
]

async function quizApi(difficulty) {
  const response = await fetch('https://quizapi.io/api/v1/questions?apiKey=MrSORkLFSsJabARtQhyloo7574YX2dquEAchMn8x&difficulty=' + difficulty + '&limit=1');
  const quizData = await response.json();

  const transformedData = quizData.map(({ question, answers, correct_answers }) => ({
    soal: question,
    hint: Object.values(answers).filter(value => value !== null),
    jawaban: Object.entries(correct_answers)
      .reduce((acc, [key, value]) => (value === 'true' ? answers[key.replace('_correct', '')] : acc), null)
  }));

  return transformedData;
}
